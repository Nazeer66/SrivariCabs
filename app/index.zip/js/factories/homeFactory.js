// app.factory('homeFactory', function($http){
//     return{
//         getFactory: function(){
//             $http.get("api/home.json").then(function(resolve){
//                 return resolve.data;
//             })
//         }
//     }
// })