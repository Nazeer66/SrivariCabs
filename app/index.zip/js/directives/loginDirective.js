app.directive('loginPage', function(){
    return{
        templateUrl:"views/login.html",
        controller:"loginCtrl"
    }
})