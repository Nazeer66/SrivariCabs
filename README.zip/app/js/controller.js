app.controller("myCtrl", function($scope, $http){
    
    
    $http.get("api/home.json").then(successCallback);

    function successCallback(response){
        $scope.homeData = response.data.data;
        console.log("home", response.data.data);
    }
    

})