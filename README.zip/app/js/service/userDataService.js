app.service('userDataService',function($http){

    // function myFun(){
    //     return $http.get('api/userData.json').then(function(sucess){
            
    //         return sucess.data.userData;
    //          console.log("service", value);
        
    // })
        
    // }
   
        
        
       
    
})