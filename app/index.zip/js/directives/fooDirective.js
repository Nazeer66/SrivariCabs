app.directive('myfooDirective', function(){
    return{
        templateUrl:"views/footer.html"
    }
})