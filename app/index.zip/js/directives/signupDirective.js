app.directive('signupPage', function(){
    return{
        templateUrl:"views/signup.html",
        controller:"signUpCtrl"
    }
})