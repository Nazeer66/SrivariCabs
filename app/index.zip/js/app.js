var app = angular.module('myApp', ['ngRoute']);


// app.config(function($routeProvider){
//     $routeProvider
//     .when('/' , {
//         templateUrl:"views/home.html"
//     })
//     .when("/prod",{
//         templateUrl:"views/product.html"
//     })
//     .when("/service",{
//         templateUrl:"views/service.html"
//     })
//     .when("/contact",{
//         templateUrl:"views/contact.html",
//         controller:"myCtrl"
//     })
//     .otherwise({
//         redirectTO:"/"
//     });
// })